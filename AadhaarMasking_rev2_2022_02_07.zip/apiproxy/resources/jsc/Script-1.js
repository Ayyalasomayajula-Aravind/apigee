
var AadharNumber = context.getVariable("AadharNumber");
 str = AadharNumber.replace(/\d(?=\d{4})/g, "X");
 //context.setVariable("response.content",str);
 // ;
 var finalresp = '{"AadharNumber":"'+str+'","Name":"Aravind"}';
 context.setVariable("response.content",finalresp);
 context.setVariable("response.header.Content-Type", "application/json")
 