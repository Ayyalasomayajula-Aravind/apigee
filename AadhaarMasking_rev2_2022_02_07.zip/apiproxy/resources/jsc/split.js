//How to fetch Aadhar Number
var AadharNumber = context.getVariable("AadharNumber");

//Fetching First five digits
var slice = AadharNumber.slice(11);


var replace = slice.replace(slice, "XXXXXXXXXXXX");
var twodigits = AadharNumber.slice(-4);
var AadharNumber = replace+twodigits;
//context.setVariable("AadharNumber",AadharNumber);
//'Hello' + ' ' + 'World';

 var finalresp = '{"AadharNumber":"'+AadharNumber+'","Name":"Aravind"}';
 context.setVariable("response.content",finalresp);
 
   /* try {
    var finalResp = {
        AadharNumber: context.getVariable("AadharNumber"),
    Name:"Aravind"
    }
    context.setVariable("response.content", JSON.stringify(finalResp));
    context.setVariable("response.header.Content-Type", "application/json; charset=utf-8");
} catch(err) {
    context.setVariable("CATCH_EXCEPTION", err);
    throw err;8?
}*/
